package com.jamescho.framework.util;

import com.jamescho.game.state.State;

import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class InputHandler implements KeyListener, MouseListener {

    private State currentState;

    public void setCurrentState(State currentState){
        this.currentState = currentState;
    }

    @Override
    public  void mouseClicked(MouseEvent e){

        }




    @Override
    public  void mouseEntered(MouseEvent e){

    }
    @Override
    public  void mouseExited(MouseEvent e){

    }
    @Override
    public  void mousePressed(MouseEvent e){

    }
    @Override
    public  void mouseReleased(MouseEvent e){

    }
    @Override
    public void keyPressed(KeyEvent e){
        currentState.onKeyRelease(e);

    }

    @Override
    public void keyReleased(KeyEvent e){
        currentState.onKeyRelease(e);
    }

    @Override
    public void keyTyped(KeyEvent arg0){

    }
}
